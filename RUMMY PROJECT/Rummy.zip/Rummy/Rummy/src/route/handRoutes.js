// routes/handRoutes.js
// const express = require('express');
// const router = express.Router();
// const handController = require('../controller/handController');

// // Create a new hand
// router.post('/', handController.createHand);

// // Get all hands
// router.get('/', handController.listHands);


// module.exports = router;
